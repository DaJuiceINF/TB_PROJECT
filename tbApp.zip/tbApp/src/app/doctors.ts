export class Doctors {

    UserId: number;
    UserName:string;
    LoginName: string;
    Password:string;
    Email:string;
    ContactNo:string;
    Address :string;
}
