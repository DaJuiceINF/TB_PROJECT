import { Doctors } from './doctors';

describe('Doctors', () => {
  it('should create an instance', () => {
    expect(new Doctors()).toBeTruthy();
  });
});
