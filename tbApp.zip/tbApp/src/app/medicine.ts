export class Medicine {

    medicineID: number;
    medicineName:string;
    medicineDescription:string;
    estimatePrice: number;
    typeOfTbID: number;
}
