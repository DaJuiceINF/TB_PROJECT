export class Symptom {
    symptomID: number;
    symptomDescription:string;
    typeOfTB:string;
}
